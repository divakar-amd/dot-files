# AWS prompt
function upl() {
  if [[ -z "$1" ]] ; then
    echo "Uplynk site cleared"
    unset UPLYNK_SITE
    return
  fi
  export UPLYNK_SITE=$1
}

function uplynk_prompt_info() {
  [[ -z $UPLYNK_SITE ]] && return
  echo "${ZSH_THEME_UPLYNK_PREFIX:=<uplynk:}${UPLYNK_SITE}${ZSH_THEME_UPLYNK_SUFFIX:=>} "
}

if [ "$SHOW_UPLYNK_PROMPT" != false ]; then
  RPROMPT='$(uplynk_prompt_info)'"$RPROMPT"
fi
